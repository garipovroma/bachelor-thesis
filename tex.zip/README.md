# latex-styles
LaTeX styles for different purposes. Currently the following styles are available:

## itmo-student-thesis.cls

A class for bachelor's and master's theses for students of ITMO University.
